<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\MeetingRoom;

class MeetingRoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       
            MeetingRoom::create([
                'room_id' => '1',
                'room_name' => 'Meeting Room 1',
                'room_capacity' => '3',
            ]);

            MeetingRoom::create([
                'room_id' => '2',
                'room_name' => 'Meeting Room 2',
                'room_capacity' => '10',
            ]);

            MeetingRoom::create([
                'room_id' => '3',
                'room_name' => 'Meeting Room 3',
                'room_capacity' => '15',
            ]);

            MeetingRoom::create([
                'room_id' => '4',
                'room_name' => 'Meeting Room 4',
                'room_capacity' => '2',
            ]);

            MeetingRoom::create([
                'room_id' => '5',
                'room_name' => 'Meeting Room 5',
                'room_capacity' => '1',
            ]);
        
       
    }
}
