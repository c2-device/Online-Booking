<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::resource('roombooking', 'App\Http\Controllers\PageRoomBookingController');
Route::resource('mybooking', 'App\Http\Controllers\MyBookingController');
Route::resource('mysubscription', 'App\Http\Controllers\MySubscribtionController');

Route::middleware("auth")->group(function() {

    Route::post('/GetMembers', [App\Http\Controllers\PageRoomBookingController::class, 'GetMembers'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('GetMembers');

    Route::post('/InserData', [App\Http\Controllers\PageRoomBookingController::class, 'InserData'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('InserData');

    Route::post('/ShowUpComing',[App\Http\Controllers\MyBookingController::class,'ShowUpComing'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('ShowUpComing');

    Route::post('/SoftDelete',[App\Http\Controllers\MyBookingController::class,'SoftDelete'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('SoftDelete');
    
    Route::post('/UpdateData',[App\Http\Controllers\MyBookingController::class,'UpdateData'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('UpdateData');

    Route::post('/UpdatePlan',[App\Http\Controllers\MySubscribtionController::class,'UpdatePlan'])
    ->middleware('throttle')
    ->middleware('cache.headers')
    ->name('UpdatePlan');
    
});
