@extends('layouts.newapp')

@section('content')

<main id="main" class="main">

    <div class="pagetitle">
      <h1>My Subscribtion</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{route('home')}}">Dashboard</a></li>
          <li class="breadcrumb-item">Online Booking</li>
          <li class="breadcrumb-item active">My Subscribtion</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">
            <h3>Select Your Plan</h3>
           <input type="hidden" value= "{{Auth::user()->flag}}" id="flag">
            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">
                <div class="card-body" id="bp">
                  <h5 class="card-title">Basic Plan <span></span></h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-currency-dollar"></i>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">
                <div class="card-body" id="ap">
                  <h5 class="card-title">Advanced Plan</h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-currency-dollar"></i>
                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->
            

            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">
              <div class="card info-card customers-card">
                <div class="card-body" id="pp">
                  <h5 class="card-title">Premium Plan</h5>
                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                    <i class="bi bi-currency-dollar"></i>
                    </div>
                  </div>

                </div>
              </div>

            </div><!-- End Customers Card -->     
            
            <div class="row mb-3">
                      <label for="inputPassword" class="col-sm-2 col-form-label">Your Current Plan </label>
                      <div class="col-sm-4">
                        <h3 i="plans">
                           @if(Auth::user()->flag=='')
                          <p>  Basic Plan</p>
                           @endif
                           @if(Auth::user()->flag=='A')
                          <p>  Advanced Plan</p>
                           @endif
                           @if(Auth::user()->flag=='P')
                          <p>  Premium Plan</p>
                           @endif
                        </h3>
                      </div>
            </div>
          </div>
        </div><!-- End Left side columns -->


        </div><!-- End Right side columns -->

      </div>
    </section>

  </main>



@endsection