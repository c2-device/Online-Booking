@extends('layouts.newapp')

@section('content')

<main id="main" class="main">

    <div class="pagetitle">
      <h1>My Booking</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{route('home')}}">Dashboard</a></li>
          <li class="breadcrumb-item">Online Booking</li>
          <li class="breadcrumb-item active">My Booking</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Form </h5>
           
              <form class='form-horizontal' method="POST">
                <div class='main_content'>
                    <div class="alert alert-danger alert-dismissible fade show error_msg1" role="alert" style="display:none;">
                        <i class="bi bi-exclamation-octagon me-1"></i>No Records Available<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <div class="alert alert-success alert-dismissible fade show save_msg1" role="alert" style="display:none;">
                        <i class="bi bi bi-clipboard-check me-1"></i>Record is deleted 
                       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <div class="row mb-3">
                      <label for="inputText" class="col-sm-2 col-form-label">My Bookings</label>
                      <div class="col-sm-4">
                      <select class="form-control" id="filter_id" name="filter_id">
                        <option value = "">Select</option>
                        <option value = "U">Upcomming Bookings</option>
                        <option value = "P">Past Bookings</option>
                      </select>
                      <span class="valid_mybooking" style="display:none"><b style="color:red">Select My Bookings</b></span>
                      </div>
                    </div>

                    <div id="mytbl" style="display:none;">
                    <table class="table table-bordered table-striped" id="table_id1">
                        <thead>
                            <tr>
                            <th class="text-center">Room No.</th>
                            <th class="text-center">Room Name</th>
                            <th class="text-center">Date</th>
                            <th class="text-center" colspan=2>Actions</th>
                            </tr>
                        </thead>
                            <tbody id="">
                            </tbody>
                    </table>
                    </div>

                    <div class="text-center">
                      <button type="button" id="btn_show" class="btn btn-primary">Submit</button>
                      <button class="btn btn-primary" id="btn_loadings" type="button" style="display:none;><span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>Loading</button>
                      <button type="reset" id="btn_resets" class="btn btn-secondary">Reset</button>
                    </div>

                     <!--Start Model-->
                   <div class="modal fade" id="UpdateModal" tabindex="-1" >
                        <div class="modal-dialog modal-lg">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title">Resechule Date & Time</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            <div class="row mb-3">
                                <label for="inputPassword" class="col-sm-2 col-form-label">Date & Time</label>
                                <div class="col-sm-4">
                                    <input type="datetime-local" id="date_time2" class="form-control" min="<?php echo $mytime1 =Date('Y-m-d')."T16:30"; ;?>" max="<?php echo  $mytime2 =Date('Y-m-d',strtotime('+10 years'))."T16:30";;?>">
                                    <span class="valid_datetime1" style="display:none"><b style="color:red">Select Date</b></span>
                                </div>
                                </div>
                           
                            <div class="text-right">
                                <button type="button" id="btn_update_data" class="btn btn-primary">Submit</button>
                            </div>

                            </div>
                           
                          </div>
                        </div>
                   </div>
                   <!--End Modal-->

                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </section>

  </main>



@endsection