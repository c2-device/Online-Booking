@extends('layouts.newapp')

@section('content')

<main id="main" class="main">

    <div class="pagetitle">
      <h1>Book Room</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="{{route('home')}}">Dashboard</a></li>
          <li class="breadcrumb-item">Online Booking</li>
          <li class="breadcrumb-item active">Book Room</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Form </h5>
           
              <form class='form-horizontal' method="POST">
                <div class='main_content'>
                    <div class="alert alert-success alert-dismissible fade show save_msg" role="alert" style="display:none;">
                        <i class="bi bi bi-clipboard-check me-1"></i>Data is saved 
                       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <div class="alert alert-danger alert-dismissible fade show error_msg" role="alert" style="display:none;">
                        <i class="bi bi-exclamation-octagon me-1"></i>Error while Saving!! Contact Administrator<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <div class="row mb-3">
                      <label for="inputText" class="col-sm-2 col-form-label">Meeting Room</label>
                      <div class="col-sm-4">
                      <select class="form-control" id="room_id" name="room_id">
                          <option value="">Select Room</option>
                        @foreach ($room as $key)
                        <option value = {{$key->room_id}}> {{$key->room_name}}</option>
                        @endforeach
                      </select>
                      <span class="valid_meetingroom" style="display:none"><b style="color:red">Select Meeting Room</b></span>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="inputPassword" class="col-sm-2 col-form-label">Member</label>
                      <div class="col-sm-4">
                        <input type="text" id="members" class="form-control" placeholder="Enter the no. of member attending" disabled>
                        <!-- <select class="form-control" id="members" name="members" disabled> 
                          
                        </select> -->
                        <span class="valid_member" style="display:none"><b style="color:red">Select Members</b></span>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="inputEmail" class="col-sm-2 col-form-label">Meeting name</label>
                      <div class="col-sm-4">
                        <input type="text" class="form-control" id="meeting_name" name="meeting_name" placeholder="Enter Meeting Name" disabled>
                        <span class="valid_meetingname" style="display:none"><b style="color:red">Enter Meeting Name</b></span>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputPassword" class="col-sm-2 col-form-label">Date & Time</label>
                      <div class="col-sm-4">
                        <input type="datetime-local" id="date_time1" class="form-control" min="<?php echo $mytime1 =Date('Y-m-d')."T16:30"; ;?>" max="<?php echo  $mytime2 =Date('Y-m-d',strtotime('+10 years'))."T16:30";;?>" disabled>
                        <span class="valid_datetime" style="display:none"><b style="color:red">Select Date</b></span>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="inputPassword" class="col-sm-2 col-form-label">Duration</label>
                      <div class="col-sm-4">
                        <select class="form-control" id="duration" name="duration" disabled>
                          <option value="">Select Duration</option>
                          <option value="30">30 mins</option>
                          <option value="60">60 mins</option>
                          <option value="90">90 mins</option>
                        </select>
                        <span class="valid_duration" style="display:none"><b style="color:red">Select Duration</b></span>
                      </div>
                    </div>

                    <div class="text-center">
                      <button type="button" id="btn_insertdata" class="btn btn-primary">Submit</button>
                      <button class="btn btn-primary" id="btn_loading" type="button" style="display:none;><span class="spinner-grow spinner-grow-sm" role="status" aria-hidden="true"></span>Loading</button>
                      <button type="reset" id="btn_reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
              </form>

            </div>
          </div>

        </div>

 
      </div>
    </section>

  </main>



@endsection