<?php

namespace App\Http\Controllers;

use App\Models\PageRoomBooking;
use Illuminate\Http\Request;
use App\Models\MeetingRoom;
use App\Models\TransactionMeetingRoom;
use Illuminate\Support\Facades\DB;
use Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class PageRoomBookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        $room = MeetingRoom::select('room_id','room_name')->get();
        return view('modules.roombooking',compact('room'));
    }

    public function GetMembers(Request $request){
        $validator = Validator::make($request->all(), [
            'room_id' => ['required','numeric'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else {  
            Artisan::call('cache:clear');
            $room_id        = $this->normalizeString($request->room_id);
            $room_capacity  = MeetingRoom::select('room_capacity')->where('room_id','=',$room_id)->get();
            $count = count($room_capacity);
            if($count=='0'){
                return response()->json(["flag"=>"X"]);
            }
            else {
                return response()->json([$room_capacity,200]);
            }
        }
    }

    public function InserData(Request $request){
        $validator = Validator::make($request->all(), [
            'room_id' => ['required','numeric'],
            'members' => ['required','numeric'],
            'room_name' => ['required'],
            'date_time' => ['required'],
            'duration' => ['required','numeric'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else{
        $now    = Date('Y-m-d');
        $user_id= Auth::id(); 

        $get_flag= DB::Select('Select FLAG from users where id = :id',['id'=>$user_id]);
        $flag=$get_flag[0]->flag;
       
        if($flag==null){
            $count_data = DB::Select('Select count(*) from transcation_meeting_room where user_id=:user_id and DATE(created_at)=:date ',[':user_id'=>$user_id,':date'=>$now]);
            $check=$count_data[0]->count;

            if($check==0){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else if($check<=5){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else {
                return response()->json(["limit"=>"Y"]);
            }
        }
        else if($flag=='A'){
            $count_data = DB::Select('Select count(*) from transcation_meeting_room where user_id=:user_id and DATE(created_at)=:date ',[':user_id'=>$user_id,':date'=>$now]);
            $check=$count_data[0]->count;

            if($check==0){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else if($check<=7){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else {
                return response()->json(["limit"=>"Y"]);
            }
           
        }
        else if($flag=='P'){
            $count_data = DB::Select('Select count(*) from transcation_meeting_room where user_id=:user_id and DATE(created_at)=:date ',[':user_id'=>$user_id,':date'=>$now]);
            $check=$count_data[0]->count;

            if($check==0){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else if($check<=10){
                $tmr = new TransactionMeetingRoom(); 
                $tmr->user_id = Auth::id(); 
                $tmr->room_id = $this->normalizeString($request->room_id);
                $tmr->room_capacity = $this->normalizeString($request->members);
                $tmr->meeting_name  = $this->normalizeString($request->room_name);
                $tmr->duration      = $this->normalizeString($request->duration);
                $tmr->date_time     = $this->normalizeString($request->date_time);
                $tmr->display       = 'Y';    
                DB::transaction(function () use ($tmr) { 
                     $tmr->save();
                }); 
                return response()->json(["flag"=>"Y"]);
            }
            else {
                return response()->json(["limit"=>"Y"]);
            }
        }
        }
    }

    public function normalizeString($str){
        $str = strip_tags($str);
        $str = preg_replace('/[\r\n\t ]+/', ' ', $str);
        $str = preg_replace('/[\"\*\/\:\<\>\?\'\|]+/', ' ', $str);
        $str = html_entity_decode( $str, ENT_QUOTES, "utf-8" );
        $str = htmlentities($str, ENT_QUOTES, "utf-8");
        $str = mb_ereg_replace("/(&)([a-z])([a-z]+;)/i", '$2', $str);
        $str = str_replace('%', '-', $str);
       return $str;
 }
   
}
