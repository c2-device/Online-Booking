<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MeetingRoom;
use App\Models\TransactionMeetingRoom;
use Illuminate\Support\Facades\DB;
use Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Carbon;

class MyBookingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
        return view('modules.mybooking');
    }

    public function ShowUpComing(Request $request){
        $validator = Validator::make($request->all(), [
            'filter_id' => ['required'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else {  
            Artisan::call('cache:clear');
            $filter_id = $request->filter_id;
            $user_id = Auth::id(); 
            $display = "Y";
            if($filter_id=='U'){
              $today=  date('Y-m-d');    
              $query = DB::Select('Select  tmr.id,tmr.user_id,tmr.room_id,tmr.meeting_name, tmr.duration, tmr.date_time, mr.room_name from transcation_meeting_room tmr
                                   Inner Join meeting_room mr on tmr.room_id=mr.room_id where tmr.user_id =:user_id and Date(tmr.updated_at)>=:today and tmr.display=:display',
                                   [':user_id'=>$user_id,':today'=>$today,':display'=>$display]);
              $count = count($query);
              if($count=='0'){
                return response()->json(["flag"=>"X"]);
                }
              else {
                $flag = array(["flag"=>"U"]);
                return response()->json([$query,$flag]);        
                }
                
            }
            else if($filter_id=='P'){
                $today=  date('Y-m-d');    
                $query = DB::Select('Select tmr.id,tmr.user_id,tmr.room_id,tmr.meeting_name, tmr.duration, tmr.date_time, mr.room_name from transcation_meeting_room tmr
                                     Inner Join meeting_room mr on tmr.room_id=mr.room_id where tmr.user_id =:user_id and Date(tmr.updated_at)<:today',
                                     [':user_id'=>$user_id,':today'=>$today]);
                $count = count($query);
                if($count=='0'){
                  return response()->json(["flag"=>"X"]);
                  }
                else {
                    $flag = array(["flag"=>"P"]);
                    return response()->json([$query,$flag]);   
                  }  
              }
              else {
                return response()->json(["flag"=>"X"]);
              }
        }

    }

    public function SoftDelete(Request $request){
        $validator = Validator::make($request->all(), [
            'id' => ['required'],
            'user_id' => ['required'],
            'room_id' => ['required'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else {  
            $id      = $request->id;
            $user_id = $request->user_id;
            $room_id = $request->room_id;
            $display = "N";
            $softdelete = TransactionMeetingRoom::where([['id','=',$id],['user_id','=',$user_id],['room_id','=',$room_id]])->update(array(
                'display'=>$display,));
            return response()->json(["flag"=>"Y"]);
        }
    }

    public function UpdateData(Request $request){
        $validator = Validator::make($request->all(), [
            'id' => ['required'],
            'user_id' => ['required'],
            'room_id' => ['required'],
            'date_time2'=>['required'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else {  
            $id         = $request->id;
            $user_id    = $request->user_id;
            $room_id    = $request->room_id;
            $date_time  = $this->normalizeString($request->date_time2);
            $update     =  TransactionMeetingRoom::where([['id','=',$id],['user_id','=',$user_id],['room_id','=',$room_id]])->update(array(
                'date_time'=>$date_time,));
            return response()->json(["flag"=>"Y"]);
        }
    }

    public function normalizeString($str){
        $str = strip_tags($str);
        $str = preg_replace('/[\r\n\t ]+/', ' ', $str);
        $str = preg_replace('/[\"\*\/\:\<\>\?\'\|]+/', ' ', $str);
        $str = html_entity_decode( $str, ENT_QUOTES, "utf-8" );
        $str = htmlentities($str, ENT_QUOTES, "utf-8");
        $str = mb_ereg_replace("/(&)([a-z])([a-z]+;)/i", '$2', $str);
        $str = str_replace('%', '-', $str);
       return $str;
 }
}
