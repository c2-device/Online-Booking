<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class MySubscribtionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user_id = Auth::id(); 
       
        return view('modules.subscribtion');
    }

    public function UpdatePlan(Request $request){
        $validator = Validator::make($request->all(), ['flag' => ['required'],
        ]);
        if ($validator->fails()) {  
            Artisan::call('cache:clear');
            return response()->json(["flag"=>"ER"]);
        }
        else {  
        $flag        = $request->flag;
        if($flag=="X"){
            $user_id     = Auth::id(); 
            $user        = User::where('id',$user_id)->update(array('flag'=>null));
        }
        else { 
            $user_id     = Auth::id(); 
            $user        = User::where('id',$user_id)->update(array('flag'=>$flag));}
       
        }
    }
}
