
<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
        <a class="nav-link " href="<?php echo e(route('home')); ?>">
            <i class="bi bi-grid"></i>
            <span>Dashboard</span>
        </a>
        </li><!-- End Dashboard Nav -->

        <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-menu-button-wide"></i><span>Online Booking</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
            <a href="<?php echo e(route('roombooking.index')); ?>">
                <i class="bi bi-circle"></i><span>Book Room</span>
            </a>
            </li>
            <li>
            <a href="<?php echo e(route('mybooking.index')); ?>">
                <i class="bi bi-circle"></i><span>My Bookings</span>
            </a>
            </li>

            <li>
            <a href="<?php echo e(route('mysubscription.index')); ?>">
                <i class="bi bi-circle"></i><span>My Subscribtion</span>
            </a>
            </li>
          
        </ul>
        </li><!-- End Components Nav -->
      
    </ul>
</aside><?php /**PATH /Users/brandonmarbaniang/Desktop/Laravel Projects/booking-app/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>