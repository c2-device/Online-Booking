$(document).ready(function () {
    $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}});

    //Display Table for Upcoming and Past Meetings
    $("#btn_show").click(function (e) { 
        e.preventDefault();
        var filter_id= $("#filter_id").val();
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        if(!filter_id==''){
            $.ajax({
                type: "POST",
                url: "/ShowUpComing",
                data: {filter_id,CSRF_TOKEN},
                success: function (response) {
                     if(response['flag']=='X'){
                        $('.error_msg1').show();
                        $('.error_msg1').delay(3000).fadeOut('slow');
                        $("#mytbl").hide();
                        return false;
                    }
                   if(response[1][0]['flag']=='U'){
                    if(response['flag']=='X'){
                        $('.error_msg1').show();
                        $('.error_msg1').delay(3000).fadeOut('slow');
                        $("#mytbl").hide();
                        return false;
                       }
                    else{
                    var res='';
                    $.each (response[0], function (key, value){
                        res +=
                        '<tr>'+
                        '<td style="display:none;" class="id">'+value.id+'</td>'+
                        '<td style="display:none;" class="user_id">'+value.user_id+'</td>'+
                        '<td style="text-align: center;" class="room_id">'+value.room_id+'</td>'+
                        '<td style="text-align: center;">'+value.meeting_name+'</td>'+
                        '<td style="text-align: center;">'+value.date_time+'</td>'+
                        '<td style="text-align: center;"><button type="button"  data-bs-toggle="modal" data-bs-target="#UpdateModal"  class="btn btn-primary btn_updatedeldata" data-backdrop="static" data-keyboard="false"><i class="bi bi-files"></i></button></td>'+
                        '<td style="text-align: center;"><button type="button" class="btn btn-danger btn_fetchdeldata"><i class="bi bi-x-lg"></i></button></td>'+
                        '</tr>';
                    }); 
                    $('#table_id1 tbody').empty();
                    $('#table_id1 tbody').append(res); 
                    $("#mytbl").show();
                    return false;
                }
                   }
                   else  if(response[1][0]['flag']=='P'){
                    if(response['flag']=='X'){
                        $('.error_msg1').show();
                        $('.error_msg1').delay(3000).fadeOut('slow');
                        $("#mytbl").hide();
                        return false;
                       }
                    else{
                    var res='';
                    $.each (response[0], function (key, value){
                        res +=
                        '<tr>'+
                        '<td style="display:none;" class="id">'+value.id+'</td>'+
                        '<td style="display:none;" class="user_id">'+value.user_id+'</td>'+
                        '<td style="text-align: center;" class="room_id">'+value.room_id+'</td>'+
                        '<td style="text-align: center;">'+value.meeting_name+'</td>'+
                        '<td style="text-align: center;">'+value.date_time+'</td>'+
                        '<td style="text-align: center;"><button type="button" class="btn btn-primary btn_updatedeldata" disabled><i class="bi bi-files"></i></button></td>'+
                        '<td style="text-align: center;"><button type="button" class="btn btn-danger btn_fetchdeldata" disabled><i class="bi bi-x-lg"></i></button></td>'+
                        '</tr>';
                    }); 
                    $('#table_id1 tbody').empty();
                    $('#table_id1 tbody').append(res); 
                    $("#mytbl").show();
                    return false;
                   }
                  }
                   
                }
            });
        }
        else {
            $(".valid_mybooking").show();
            return false;
        }
        
    });

    $("#filter_id").change(function(){
        $(".valid_mybooking").hide();
      });

    // Delete(soft delete) a given row
    $(document).on("click",".btn_fetchdeldata",(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var id         =    $(this).parents("tr").find(".id").text();
        var user_id    =    $(this).parents("tr").find(".user_id").text();
        var room_id    =    $(this).parents("tr").find(".room_id").text();
        var filter_id  =    "U";
        $.ajax({
            type: "POST",
            url: "/SoftDelete",
            data: {id,user_id,room_id,CSRF_TOKEN},
            success: function (response) {
                if(response['flag']=='Y'){
                    $(".save_msg1").show();
                    $('.save_msg1').delay(3000).fadeOut('slow');
                    $.ajax({
                        type: "POST",
                        url: "/ShowUpComing",
                        data: {filter_id,CSRF_TOKEN},
                        success: function (response) {
                            if(response['flag']=='X'){
                                $('.error_msg1').show();
                                $('.error_msg1').delay(3000).fadeOut('slow');
                                $("#mytbl").hide();
                                return false;
                            }
                           if(response[1][0]['flag']=='U'){
                            var res='';
                            $.each (response[0], function (key, value){
                                res +=
                                '<tr>'+
                                '<td style="display:none;" class="id">'+value.id+'</td>'+
                                '<td style="display:none;" class="user_id">'+value.user_id+'</td>'+
                                '<td style="text-align: center;" class="room_id">'+value.room_id+'</td>'+
                                '<td style="text-align: center;">'+value.meeting_name+'</td>'+
                                '<td style="text-align: center;">'+value.date_time+'</td>'+
                                '<td style="text-align: center;"><button type="button" class="btn btn-primary btn_updatedeldata"  data-bs-toggle="modal" data-bs-target="#UpdateModal"  class="btn btn-primary btn_updatedeldata" data-backdrop="static" data-keyboard="false"><i class="bi bi-files"></i></button></td>'+
                                '<td style="text-align: center;"><button type="button" class="btn btn-danger btn_fetchdeldata"><i class="bi bi-x-lg"></i></button></td>'+
                                '</tr>';
                            });
                            $('#table_id1 tbody').empty();
                            $('#table_id1 tbody').append(res); 
                            $("#mytbl").show();
                            return false;
                        }
                        }
                    });
                }
            }
        });
    }));

    //Update a given row in the table
    $(document).on("click",".btn_updatedeldata",(function(){
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var id         =    $(this).parents("tr").find(".id").text();
        var user_id    =    $(this).parents("tr").find(".user_id").text();
        var room_id    =    $(this).parents("tr").find(".room_id").text();

        $("#btn_update_data").click(function (e) { 
            var date_time2 = $("#date_time2").val();
           if(date_time2==''){
            $('.valid_datetime1').show();
           }
           $.ajax({
            type: "POST",
            url: "UpdateData",
            data: {date_time2,CSRF_TOKEN,id,room_id,user_id},
            success: function (response) {
                if(response['flag']=='Y'){
                  alert('Date and Time Updated');
                  location.reload();
                }
                if(response['flag']=='ER'){
                   alert("Validation Error"); return false;
                }
            }
           });           
        });
    }));

    $("#date_time2").click(function(){
        $('.valid_datetime1').hide();
    })

    //Select Plans
    $("#bp").click(function (e) { 
        e.preventDefault();
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        var  flag      = "X";
        if(confirm("Are you sure you want to subscribe to this Basic Plan?")){
           $.ajax({
            type: "POST",
            url: "UpdatePlan",
            data: {flag,CSRF_TOKEN},
            success: function (response) {
                location.reload();
            }
           });
        }
        else{
            return false;
        }
    });

    $("#ap").click(function (e) { 
        e.preventDefault();
      
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            var  flag      = "A";
            if(confirm("Are you sure you want to subscribe to this Advanced Plan?")){
               $.ajax({
                type: "POST",
                url: "UpdatePlan",
                data: {flag,CSRF_TOKEN},
                success: function (response) {
                    location.reload();
                }
               });
            }
            else{
                return false;
            }
       
       
    });

    $("#pp").click(function (e) { 
        e.preventDefault();
      
            var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
            var  flag      = "P";
            if(confirm("Are you sure you want to subscribe to this Premium Plan?")){
               $.ajax({
                type: "POST",
                url: "UpdatePlan",
                data: {flag,CSRF_TOKEN},
                success: function (response) {
                    location.reload();
                }
               });
            }
            else{
                return false;
            }
        
        
    });
});