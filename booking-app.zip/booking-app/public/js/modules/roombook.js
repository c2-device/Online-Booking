

$(document).ready(function(){$.ajaxSetup({headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}});

  $('#members').keypress(function (e) {    
    var charCode = (e.which) ? e.which : event.keyCode    
   if (String.fromCharCode(charCode).match(/[^0-9]/g))    
       return false;                        
 });


  //Check and Enable form using room id and get the numbers of members
  $("#room_id").change(function (e) { 
    $(".valid_meetingroom").hide();
    $(".error_msg").hide();
    e.preventDefault();
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var room_id= $('#room_id').val();
    if (room_id>=1){
      $("#members").prop('disabled', false);
      $("#date_time1").prop('disabled', false);
      $("#duration").prop('disabled', false);
      $("#meeting_name").prop('disabled', false);
      $("#members").blur(function (e) { 
        var members = $("#members").val();
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: "/GetMembers",
            data: { CSRF_TOKEN,room_id},
            success: function (response) {
              if(response['flag']=='ER'){
                alert('Server Error');
                 return false;
              }
              else  if(response['flag']=='X'){
                alert('DB Error');
                return false;
              }
              else if(members<=response[0][0]['room_capacity']) {
              //do nothing
              $("#date_time1").prop('disabled', false);
              $("#duration").prop('disabled', false);
              $("#meeting_name").prop('disabled', false);
              }
              else if(members>response[0][0]['room_capacity']) {
              alert('Room Capicty should be less than '+response[0][0]['room_capacity']);
              $("#date_time1").prop('disabled', true);
              $("#duration").prop('disabled', true);
              $("#meeting_name").prop('disabled', true);
              return false;
              }
            }
          });
      });
    }
    else {
      $("#members").prop('disabled', true);
      $("#date_time1").prop('disabled', true);
      $("#duration").prop('disabled', true);
      $("#meeting_name").prop('disabled', true);
    }
  });

  $("#btn_insertdata").click(function (e) { 
    e.preventDefault();
    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    var room_id    = $("#room_id").val();
    var members    = $("#members").val();
    var room_name  = $("#meeting_name").val();
    var date_time  = $("#date_time1").val();
    var duration   = $("#duration").val();
    if(room_id==''){
      $(".valid_meetingroom").show(); return false;
    }
    else if (members==''){
      $('.valid_member').show();return false;
    }
    else if(room_name==''){
      $('.valid_meetingname').show();return false;
    }
    else if(date_time==''){
      $('.valid_datetime').show();return false;
    }
    else if(duration==''){
      $('.valid_duration').show();return false;
    }

    $.ajax({
      type: "POST",
      url: "/InserData",
      data: {CSRF_TOKEN,room_id,members,room_name,date_time,duration},
      beforeSend: function() {
        $('#btn_loading').show();
        $('#btn_insertdata').hide();
        $('#btn_reset').hide();
     },
     complete: function(){
        $('#btn_loading').hide();
        $('#btn_insertdata').show();
        $('#btn_reset').show();
   },
    success: function (response) {
      if(response['limit']=='Y'){
        alert('You have exhaust your limit, upgrade your plan!!!');
        $("#room_id").prop('selectedIndex','');
        $("#members").val('');
        $("#meeting_name").val("");
        $("#date_time1").val("");
        $("#duration").prop('selectedIndex','');
        return false;
     }
     
      else if(response['flag']=='Y'){
        alert('Your Room no is '+room_id+' Room Name is '+room_name+' ');
        $(".room_no").text(room_id);
        $(".room_name").text(room_name);
        $(".save_msg").show();
        $('.save_msg').delay(5000).fadeOut('slow'); 
        $("#room_id").prop('selectedIndex','');
        $("#members").val('');
        $("#meeting_name").val("");
        $("#date_time1").val("");
        $("#duration").prop('selectedIndex','');
        return false;
      }
      else  if(response['flag']=='ER'){
        alert("Validation Error");return false;
      }  
      else {
        $(".error_msg").show();
        $('.error_msg').delay(3000).fadeOut('slow');
        return false;
      }  
      }
    });
  });



  $("#members").change(function(){
    $(".valid_member").hide();
    $(".error_msg").hide();
  });

  $("#meeting_name").click(function(){
    $(".valid_meetingname").hide();
    $(".error_msg").hide();
  });

  $("#date_time1").change(function(){
    $(".valid_datetime").hide();
    $(".error_msg").hide();
  });

  $("#duration").change(function(){
    $(".valid_duration").hide();
    $(".error_msg").hide();
  });
  
});
